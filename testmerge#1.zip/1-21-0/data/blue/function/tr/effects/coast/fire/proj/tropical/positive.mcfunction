execute store result score #.rng blue.misc run random value 1..12
execute if score #.rng blue.misc matches 1 run effect give @s speed 3 0
execute if score #.rng blue.misc matches 2 run effect give @s haste 3 0
execute if score #.rng blue.misc matches 3 run effect give @s strength 3 0
execute if score #.rng blue.misc matches 4 run effect give @s fire_resistance 3 0
execute if score #.rng blue.misc matches 5 run effect give @s regeneration 5 0
execute if score #.rng blue.misc matches 6 run effect give @s absorption 2 0
execute if score #.rng blue.misc matches 7 run effect give @s saturation 1 0
execute if score #.rng blue.misc matches 8 run effect give @s resistance 2 0
execute if score #.rng blue.misc matches 9 run effect give @s luck 3 0
execute if score #.rng blue.misc matches 10 run effect give @s dolphins_grace 2 0
execute if score #.rng blue.misc matches 11 run effect give @s night_vision 3 0
execute if score #.rng blue.misc matches 12 run effect give @s conduit_power 3 0