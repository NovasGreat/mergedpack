execute positioned ^ ^ ^0.1 unless entity @s[distance=..0.3] run function blue:tr/inv/transfer/raycast/silence
particle item{item:silence_armor_trim_smithing_template} ~ ~1 ~ 0.1 0.1 0.1 0.05 2