execute if items entity @s container.* wayfinder_armor_trim_smithing_template unless entity @s[tag=blue.tr.wayfinder] run function blue:tr/inv/templates/macro {trim:wayfinder}
execute if items entity @s weapon.offhand wayfinder_armor_trim_smithing_template unless entity @s[tag=blue.tr.wayfinder] run function blue:tr/inv/templates/macro {trim:wayfinder}
execute if items entity @s container.* silence_armor_trim_smithing_template unless entity @s[tag=blue.tr.silence] run function blue:tr/inv/templates/macro {trim:silence}
execute if items entity @s weapon.offhand silence_armor_trim_smithing_template unless entity @s[tag=blue.tr.silence] run function blue:tr/inv/templates/macro {trim:silence}
execute if items entity @s container.* shaper_armor_trim_smithing_template unless entity @s[tag=blue.tr.shaper] run function blue:tr/inv/templates/macro {trim:shaper}
execute if items entity @s weapon.offhand shaper_armor_trim_smithing_template unless entity @s[tag=blue.tr.shaper] run function blue:tr/inv/templates/macro {trim:shaper}
execute if items entity @s container.* raiser_armor_trim_smithing_template unless entity @s[tag=blue.tr.raiser] run function blue:tr/inv/templates/macro {trim:raiser}
execute if items entity @s weapon.offhand raiser_armor_trim_smithing_template unless entity @s[tag=blue.tr.raiser] run function blue:tr/inv/templates/macro {trim:raiser}
execute if items entity @s container.* sentry_armor_trim_smithing_template unless entity @s[tag=blue.tr.sentry] run function blue:tr/inv/templates/macro {trim:sentry}
execute if items entity @s weapon.offhand sentry_armor_trim_smithing_template unless entity @s[tag=blue.tr.sentry] run function blue:tr/inv/templates/macro {trim:sentry}
execute if items entity @s container.* spire_armor_trim_smithing_template unless entity @s[tag=blue.tr.spire] run function blue:tr/inv/templates/macro {trim:spire}
execute if items entity @s weapon.offhand spire_armor_trim_smithing_template unless entity @s[tag=blue.tr.spire] run function blue:tr/inv/templates/macro {trim:spire}
execute if items entity @s container.* coast_armor_trim_smithing_template unless entity @s[tag=blue.tr.coast] run function blue:tr/inv/templates/macro {trim:coast}
execute if items entity @s weapon.offhand coast_armor_trim_smithing_template unless entity @s[tag=blue.tr.coast] run function blue:tr/inv/templates/macro {trim:coast}
execute if items entity @s container.* snout_armor_trim_smithing_template unless entity @s[tag=blue.tr.snout] run function blue:tr/inv/templates/macro {trim:snout}
execute if items entity @s weapon.offhand snout_armor_trim_smithing_template unless entity @s[tag=blue.tr.snout] run function blue:tr/inv/templates/macro {trim:snout}
execute if items entity @s container.* ward_armor_trim_smithing_template unless entity @s[tag=blue.tr.ward] run function blue:tr/inv/templates/macro {trim:ward}
execute if items entity @s weapon.offhand ward_armor_trim_smithing_template unless entity @s[tag=blue.tr.ward] run function blue:tr/inv/templates/macro {trim:ward}
execute if items entity @s container.* dune_armor_trim_smithing_template unless entity @s[tag=blue.tr.dune] run function blue:tr/inv/templates/macro {trim:dune}
execute if items entity @s weapon.offhand dune_armor_trim_smithing_template unless entity @s[tag=blue.tr.dune] run function blue:tr/inv/templates/macro {trim:dune}
execute if items entity @s container.* wild_armor_trim_smithing_template unless entity @s[tag=blue.tr.wild] run function blue:tr/inv/templates/macro {trim:wild}
execute if items entity @s weapon.offhand wild_armor_trim_smithing_template unless entity @s[tag=blue.tr.wild] run function blue:tr/inv/templates/macro {trim:wild}
execute if items entity @s container.* tide_armor_trim_smithing_template unless entity @s[tag=blue.tr.tide] run function blue:tr/inv/templates/macro {trim:tide}
execute if items entity @s weapon.offhand tide_armor_trim_smithing_template unless entity @s[tag=blue.tr.tide] run function blue:tr/inv/templates/macro {trim:tide}
execute if items entity @s container.* host_armor_trim_smithing_template unless entity @s[tag=blue.tr.host] run function blue:tr/inv/templates/macro {trim:host}
execute if items entity @s weapon.offhand host_armor_trim_smithing_template unless entity @s[tag=blue.tr.host] run function blue:tr/inv/templates/macro {trim:host}
execute if items entity @s container.* eye_armor_trim_smithing_template unless entity @s[tag=blue.tr.eye] run function blue:tr/inv/templates/macro {trim:eye}
execute if items entity @s weapon.offhand eye_armor_trim_smithing_template unless entity @s[tag=blue.tr.eye] run function blue:tr/inv/templates/macro {trim:eye}
execute if items entity @s container.* rib_armor_trim_smithing_template unless entity @s[tag=blue.tr.rib] run function blue:tr/inv/templates/macro {trim:rib}
execute if items entity @s weapon.offhand rib_armor_trim_smithing_template unless entity @s[tag=blue.tr.rib] run function blue:tr/inv/templates/macro {trim:rib}
execute if items entity @s container.* vex_armor_trim_smithing_template unless entity @s[tag=blue.tr.vex] run function blue:tr/inv/templates/macro {trim:vex}
execute if items entity @s weapon.offhand vex_armor_trim_smithing_template unless entity @s[tag=blue.tr.vex] run function blue:tr/inv/templates/macro {trim:vex}
execute if score #.tr.template_clearing blue.config matches 2 run function blue:tr/inv/templates/non_own
execute if score #.tr.template_clearing blue.config matches 1 run clear @s #blue:tr/templates[!custom_data~{blue:trim}]
advancement revoke @s only blue:tr/has_template