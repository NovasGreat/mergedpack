playsound ui.button.click player @s 0 -128 0 0 1 0.75
execute store result storage blue:data trims.temp.export.objective_type int 1 run scoreboard players get #.tr.objective_type blue.config
execute store result storage blue:data trims.temp.export.objective_announcements int 1 run scoreboard players get #.tr.objective_announcements blue.config
execute store result storage blue:data trims.temp.export.template_clearing int 1 run scoreboard players get #.tr.template_clearing blue.config
execute store result storage blue:data trims.temp.export.require_unlock int 1 run scoreboard players get #.tr.require_unlock blue.config
execute store result storage blue:data trims.temp.export.allow_empowerment int 1 run scoreboard players get #.tr.allow_empowerment blue.config
execute store result storage blue:data trims.temp.export.limit_owned_trims int 1 run scoreboard players get #.tr.limit_owned_trims blue.config
execute store result storage blue:data trims.temp.export.random_task_defender int 1 run scoreboard players get #.tr.random_task_defender blue.config
execute store result storage blue:data trims.temp.export.death_transfer_amount int 1 run scoreboard players get #.tr.death_transfer_amount blue.config
execute store result storage blue:data trims.temp.export.manual_transferring int 1 run scoreboard players get #.tr.manual_transferring blue.config
execute store result storage blue:data trims.temp.export.manual_untrimming int 1 run scoreboard players get #.tr.manual_untrimming blue.config
execute store result storage blue:data trims.temp.export.owner_finder int 1 run scoreboard players get #.tr.owner_finder blue.config
execute store result storage blue:data trims.temp.export.reload_message int 1 run scoreboard players get #.tr.reload_message blue.config
execute store result storage blue:data trims.temp.export.wind_barrage_duration int 1 run scoreboard players get #.flow.wind_barrage_duration blue.config
execute store result storage blue:data trims.temp.export.throw_cooldown int 1 run scoreboard players get #.shaper.throw_cooldown blue.config
execute store result storage blue:data trims.temp.export.disfigure_time int 1 run scoreboard players get #.eye.disfigure_time blue.config
execute store result storage blue:data trims.temp.export.auto_damage int 1 run scoreboard players get #.ward.auto_damage blue.config
execute store result storage blue:data trims.temp.export.trap_limit int 1 run scoreboard players get #.wild.trap_limit blue.config
execute store result storage blue:data trims.temp.export.gamble_multiplier int 1 run scoreboard players get #.snout.gamble_multiplier blue.config
execute store result storage blue:data trims.temp.export.gamble_limit int 1 run scoreboard players get #.snout.gamble_limit blue.config
execute store result storage blue:data trims.temp.export.tracker_range int 1 run scoreboard players get #.wayfinder.tracker_range blue.config
execute store result storage blue:data trims.temp.export.void_return int 1 run scoreboard players get #.wayfinder.void_return blue.config
execute store result storage blue:data trims.temp.export.strict_skull int 1 run scoreboard players get #.rib.strict_skull blue.config
execute store result storage blue:data trims.temp.export.strict_ashen int 1 run scoreboard players get #.rib.strict_ashen blue.config
execute store result storage blue:data trims.temp.export.strict_scorch int 1 run scoreboard players get #.rib.strict_scorch blue.config
execute store result storage blue:data trims.temp.export.strict_spawn int 1 run scoreboard players get #.rib.strict_spawn blue.config
execute store result storage blue:data trims.temp.export.origin_tp int 1 run scoreboard players get #.spire.origin_tp blue.config
execute store result storage blue:data trims.temp.export.aperture int 1 run scoreboard players get #.spire.aperture blue.config
execute store result storage blue:data trims.temp.export.no_gravity int 1 run scoreboard players get #.spire.no_gravity blue.config
execute store result storage blue:data trims.temp.export.bonus_emeralds int 1 run scoreboard players get #.sentry.bonus_emeralds blue.config
execute store result storage blue:data trims.temp.export.bonus_shards int 1 run scoreboard players get #.silence.bonus_shards blue.config
execute store result storage blue:data trims.temp.export.vortex_griefing int 1 run scoreboard players get #.silence.vortex_griefing blue.config
execute store result storage blue:data trims.temp.export.uncap_proficiency int 1 run scoreboard players get #.raiser.uncap_proficiency blue.config
function blue:tr/settings/z/export with storage blue:data trims.temp.export
data remove storage blue:data trims.temp.export